from faker import Faker
fake = Faker(locale='pt_PT')

from faker.providers import BaseProvider

PROCEDURE_NOTES = {
    "Observação de Manchas de Sangue": [
        {"Nota": "As manchas de sangue indicam a posição do corpo no momento da morte."},
        {"Nota": "A análise das manchas de sangue revelou a possível trajetória do objeto utilizado no ataque."},
        {"Nota": "A presença de múltiplas manchas de sangue sugere uma luta intensa entre a vítima e o agressor antes da morte."}
    ],
    "Recolha de Impressões Digitais": [
        {"Nota": "As impressões digitais correspondem às do suspeito principal, corroborando sua presença no local do crime."},
        {"Nota": "A ausência de impressões digitais em determinados objetos indica uma possível limpeza do local por parte do suspeito."},
        {"Nota": "As impressões digitais encontradas em um segundo local de crime foram confirmadas como pertencentes ao mesmo indivíduo, ligando-o a múltiplos incidentes."}
    ],
    "Revistar o Local de Trabalho": [
        {"Nota": "Durante a revista ao local de trabalho, foram encontrados documentos suspeitos relacionados a atividades ilegais."},
        {"Nota": "A descoberta de um cofre escondido durante a revista sugere a possibilidade de atividades ilícitas dentro da empresa."},
        {"Nota": "A entrevista com colegas de trabalho revelou uma atmosfera de hostilidade entre o suspeito e a vítima, sugerindo um motivo para o crime."}
    ],
    "Recolha de Vestígios de ADN": [
        {"Nota": "O ADN encontrado nas unhas da vítima corresponde ao perfil genético do suspeito, fornecendo evidências cruciais para sua ligação ao crime."},
        {"Nota": "A análise do ADN encontrou correspondências com perfis genéticos anteriormente catalogados em bancos de dados criminais."},
        {"Nota": "O ADN encontrado em uma cena de crime anterior foi ligado ao mesmo suspeito, indicando um padrão comportamental."}
    ],
    "Recolha de Vestígios de Pólvora": [
        {"Nota": "Os vestígios de pólvora foram encontrados nas mãos do suspeito, sugerindo sua proximidade com a arma no momento do disparo."},
        {"Nota": "A presença de resíduos de pólvora em uma segunda cena de crime indica a possibilidade de um único perpetrador em ambos os incidentes."},
        {"Nota": "Os vestígios de pólvora foram encontrados não apenas nas mãos do suspeito, mas também em sua roupa, sugerindo sua proximidade com a arma no momento do disparo."}
    ],
    "Monitorização de Suspeitos": [
        {"Nota": "O suspeito foi visto se encontrando com um indivíduo conhecido por suas conexões com o submundo criminoso."},
        {"Nota": "A análise do comportamento do suspeito revelou uma mudança repentina em sua rotina diária coincidindo com o horário do crime."},
        {"Nota": "Durante a observação, o suspeito foi visto se encontrando com um indivíduo conhecido por suas conexões com o submundo criminoso."}
    ],
    "Recolha de Vestígios de Sangue": [
        {"Nota": "Os vestígios de sangue encontrados no veículo do suspeito coincidem com o tipo sanguíneo da vítima."},
        {"Nota": "A análise forense do sangue revelou a presença de substâncias químicas específicas, sugerindo a possível origem do agressor."},
        {"Nota": "A identificação do tipo sanguíneo encontrado no local do crime excluiu outros possíveis suspeitos, estreitando o foco da investigação."}
    ],
    "Inquérito": [
        {"Nota": "Foram obtidas informações cruciais de testemunhas oculares que corroboraram a versão dos eventos apresentada pelo suspeito."},
        {"Nota": "A análise das respostas do cliente revelou inconsistências que foram posteriormente exploradas para obter mais detalhes sobre sua participação no crime."},
        {"Nota": "Durante o inquérito, foram obtidas informações cruciais de testemunhas oculares que corroboraram a versão dos eventos apresentada pelo suspeito."}
    ],
    "Pizza Party": [
        {"Nota": "A festa de pizza proporcionou um ambiente descontraído para discussões informais, levando a uma troca de ideias que resultou em novas linhas de investigação."},
        {"Nota": "A partilha de histórias pessoais durante a festa ajudou a construir empatia entre os membros da equipe, fortalecendo sua colaboração futura."},
        {"Nota": "A festa de pizza proporcionou uma oportunidade valiosa para fortalecer os laços entre os membros da equipe de investigação, melhorando assim a colaboração e o moral geral."}
    ]
}


class ProcedureProvider(BaseProvider):
    def procedure(self, procedure) -> str:
        """Generates a random procedure note.
        >>> faker.procedure("Inquérito")
        'Foram obtidas informações cruciais de testemunhas oculares que corroboraram a versão dos eventos apresentada pelo suspeito.'
        >>> faker.procedure("Recolha de Vestígios de Sangue")
        'Os vestígios de sangue encontrados no veículo do suspeito coincidem com o tipo sanguíneo da vítima.'
        """

        return fake.random.choice(PROCEDURE_NOTES[procedure])["Nota"]
