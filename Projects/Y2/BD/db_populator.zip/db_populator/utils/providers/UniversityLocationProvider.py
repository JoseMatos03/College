from faker import Faker
fake = Faker(locale='pt_PT')

from faker.providers import BaseProvider

UNIVERSITY_SPACES = {
    "Universidade de Lisboa (ULisboa)": [
        "Faculdade de Ciências",
        "Faculdade de Letras",
        "Faculdade de Direito",
        "Faculdade de Medicina",
        "Instituto Superior Técnico"
    ],
    "Universidade do Porto (UP)": [
        "Faculdade de Engenharia",
        "Faculdade de Economia",
        "Faculdade de Letras",
        "Faculdade de Medicina",
        "Faculdade de Ciências"
    ],
    "Universidade de Coimbra (UC)": [
        "Faculdade de Direito",
        "Faculdade de Medicina",
        "Faculdade de Letras",
        "Faculdade de Economia",
        "Faculdade de Ciências e Tecnologia"
    ],
    "Universidade Nova de Lisboa (UNL)": [
        "Faculdade de Ciências e Tecnologia",
        "Faculdade de Direito",
        "Faculdade de Ciências Sociais e Humanas",
        "Faculdade de Economia",
        "Instituto de Higiene e Medicina Tropical"
    ],
    "Universidade de Aveiro (UA)": [
        "Departamento de Engenharia Mecânica",
        "Departamento de Línguas e Culturas",
        "Departamento de Biologia",
        "Escola Superior de Design",
        "Departamento de Economia, Gestão e Engenharia Industrial"
    ],
    "Universidade de Évora (UE)": [
        "Escola de Ciências e Tecnologia",
        "Escola de Artes",
        "Escola de Ciências Sociais",
        "Escola de Enfermagem São João de Deus",
        "Escola de Direito"
    ],
    "Universidade da Beira Interior (UBI)": [
        "Faculdade de Engenharia",
        "Faculdade de Ciências Sociais e Humanas",
        "Faculdade de Artes e Letras",
        "Faculdade de Ciências da Saúde",
        "Faculdade de Ciências"
    ],
    "Universidade de Trás-os-Montes e Alto Douro (UTAD)": [
        "Escola de Ciências Agrárias e Veterinárias",
        "Escola de Ciências Humanas e Sociais",
        "Escola de Ciências e Tecnologia",
        "Escola de Ciências da Vida e do Ambiente",
        "Escola de Direito"
    ],
    "Universidade da Madeira (UMa)": [
        "Faculdade de Ciências Sociais",
        "Faculdade de Artes e Humanidades",
        "Faculdade de Ciências Exatas e da Engenharia",
        "Faculdade de Ciências da Vida",
        "Faculdade de Medicina"
    ],
    "Universidade dos Açores (UAc)": [
        "Faculdade de Ciências Agrárias",
        "Faculdade de Ciências e Tecnologia",
        "Faculdade de Economia e Gestão",
        "Faculdade de Letras e Ciências Humanas",
        "Faculdade de Medicina"
    ],
    "Universidade Lusófona de Humanidades e Tecnologias (ULHT)": [
        "Faculdade de Direito",
        "Faculdade de Arquitetura e Urbanismo",
        "Faculdade de Ciências Sociais e Humanas",
        "Faculdade de Medicina",
        "Faculdade de Engenharia"
    ],
    "Universidade Católica Portuguesa (UCP)": [
        "Faculdade de Ciências Humanas",
        "Faculdade de Ciências Económicas e Empresariais",
        "Faculdade de Direito",
        "Faculdade de Medicina",
        "Faculdade de Teologia"
    ],
    "Universidade Lusíada (ULusíada)": [
        "Faculdade de Direito",
        "Faculdade de Arquitetura e Artes Visuais",
        "Faculdade de Ciências Sociais e Humanas",
        "Faculdade de Engenharia e Tecnologias",
        "Faculdade de Ciências da Economia e da Empresa"
    ],
    "Universidade Autónoma de Lisboa (UAL)": [
        "Faculdade de Direito",
        "Faculdade de Ciências Sociais e Humanas",
        "Faculdade de Economia e Gestão",
        "Faculdade de Psicologia",
        "Faculdade de Medicina"
    ],
    "Universidade Europeia (UE)": [
        "Faculdade de Ciências Humanas e Sociais",
        "Faculdade de Ciências da Saúde",
        "Faculdade de Direito",
        "Faculdade de Gestão e Economia",
        "Faculdade de Arquitetura e Design"
    ],
    "Universidade Fernando Pessoa (UFP)": [
        "Faculdade de Ciências",
        "Faculdade de Educação e Psicologia",
        "Faculdade de Ciências da Saúde",
        "Faculdade de Ciências Humanas e Sociais",
        "Faculdade de Engenharia"
    ],
    "Universidade Portucalense Infante D. Henrique (UPT)": [
        "Faculdade de Direito",
        "Faculdade de Ciências Empresariais",
        "Faculdade de Psicologia e de Ciências da Educação",
        "Faculdade de Economia e Gestão",
        "Faculdade de Engenharia"
    ],
    "Universidade Lusófona do Porto (ULP)": [
        "Faculdade de Ciências da Saúde",
        "Faculdade de Direito",
        "Faculdade de Ciências da Educação e do Desporto",
        "Faculdade de Economia e Gestão",
        "Faculdade de Engenharia"
    ],
    "Universidade Aberta (UAb)": [
        "Departamento de Matemática e Tecnologia",
        "Departamento de Ciências Sociais e de Gestão",
        "Departamento de Educação e Ensino a Distância",
        "Departamento de Ciências e Tecnologias",
        "Departamento de Humanidades"
    ],
    "Instituto Politécnico de Lisboa (IPL)": [
        "Escola Superior de Tecnologia da Saúde",
        "Escola Superior de Comunicação Social",
        "Escola Superior de Dança",
        "Escola Superior de Música",
        "Escola Superior de Educação"
    ],
    "Instituto Politécnico do Porto (IPP)": [
        "Escola Superior de Tecnologia e Gestão",
        "Escola Superior de Educação",
        "Instituto Superior de Engenharia",
        "Escola Superior de Saúde",
        "Escola Superior de Artes e Design"
    ],
    "Instituto Politécnico de Coimbra (IPC)": [
        "Escola Superior de Educação",
        "Escola Superior de Tecnologia da Saúde",
        "Instituto Superior de Contabilidade e Administração",
        "Escola Superior Agrária",
        "Escola Superior de Tecnologia"
    ],
    "Instituto Politécnico de Leiria (IPLeiria)": [
        "Escola Superior de Educação e Ciências Sociais",
        "Escola Superior de Tecnologia e Gestão",
        "Escola Superior de Artes e Design",
        "Escola Superior de Saúde",
        "Escola Superior de Turismo e Tecnologia do Mar"
    ],
    "Instituto Politécnico de Bragança (IPB)": [
        "Escola Superior de Educação",
        "Escola Superior de Tecnologia e Gestão",
        "Escola Superior de Saúde",
        "Escola Superior Agrária",
        "Escola Superior de Comunicação, Administração e Turismo"
    ],
    "Instituto Politécnico de Santarém (IPSantarem)": [
        "Escola Superior de Educação",
        "Escola Superior de Desporto",
        "Escola Superior de Gestão e Tecnologia",
        "Escola Superior de Saúde",
        "Escola Superior de Agrária"
    ],
    "Instituto Politécnico de Setúbal (IPS)": [
        "Escola Superior de Tecnologia",
        "Escola Superior de Ciências Empresariais",
        "Escola Superior de Saúde",
        "Escola Superior de Educação",
        "Escola Superior de Tecnologia de Setúbal"
    ],
    "Instituto Politécnico de Viseu (IPV)": [
        "Escola Superior de Educação",
        "Escola Superior de Tecnologia e Gestão",
        "Escola Superior de Saúde",
        "Escola Superior Agrária",
        "Escola Superior de Tecnologia e Gestão de Lamego"
    ],
    "Instituto Politécnico de Tomar (IPT)": [
        "Escola Superior de Tecnologia",
        "Escola Superior de Gestão",
        "Escola Superior de Tecnologia de Abrantes",
        "Escola Superior de Tecnologia de Tomar",
        "Escola Superior de Educação"
    ],
    "Instituto Politécnico de Castelo Branco (IPCB)": [
        "Escola Superior de Artes Aplicadas",
        "Escola Superior de Tecnologia",
        "Escola Superior de Educação",
        "Escola Superior de Saúde Dr. Lopes Dias",
        "Escola Superior de Gestão de Idanha-a-Nova"
    ],
    "Instituto Politécnico da Guarda (IPG)": [
        "Escola Superior de Educação, Comunicação e Desporto",
        "Escola Superior de Saúde",
        "Escola Superior de Tecnologia e Gestão",
        "Escola Superior de Turismo e Hotelaria",
        "Escola Superior de Estudos Jurídicos"
    ],
    "Instituto Politécnico de Portalegre (IPP)": [
        "Escola Superior de Tecnologia e Gestão",
        "Escola Superior de Saúde",
        "Escola Superior de Educação",
        "Escola Superior Agrária",
        "Escola Superior de Artes e Design"
    ],
    "Instituto Politécnico de Beja (IPBeja)": [
        "Escola Superior de Educação",
        "Escola Superior de Tecnologia e Gestão",
        "Escola Superior Agrária",
        "Escola Superior de Saúde",
        "Escola Superior de Artes Aplicadas"
    ],
    "Instituto Politécnico de Cávado e do Ave (IPCA)": [
        "Escola Superior de Tecnologia",
        "Escola Superior de Gestão",
        "Escola Superior de Design",
        "Escola Superior de Hotelaria e Turismo",
        "Escola Superior de Saúde"
    ],
    "Instituto Politécnico de Viana do Castelo (IPVC)": [
        "Escola Superior de Educação",
        "Escola Superior de Tecnologia e Gestão",
        "Escola Superior Agrária",
        "Escola Superior de Saúde",
        "Escola Superior de Ciências Empresariais"
    ],
    "Instituto Politécnico de Braga (IPBraga)": [
        "Escola Superior de Educação",
        "Escola Superior de Tecnologia",
        "Escola Superior de Gestão",
        "Escola Superior de Saúde",
        "Escola Superior de Artes e Design"
    ],
    "Instituto Politécnico de Santarém (IPSantarem)": [
        "Escola Superior de Educação",
        "Escola Superior de Desporto",
        "Escola Superior de Gestão e Tecnologia",
        "Escola Superior de Saúde",
        "Escola Superior de Agrária"
    ],
    "Instituto Politécnico de Macau (IPM)": [
        "Escola Superior de Línguas e Tradução",
        "Escola Superior de Tecnologia",
        "Escola Superior de Ciência e Tecnologia",
        "Escola Superior de Artes",
        "Escola Superior de Educação Física e Desporto"
    ]
}


class UniversityLocationProvider(BaseProvider):
    def university_location(self) -> str:
        """Generates a random university location.
        >>> faker.university_location()
        'Faculdade de Ciências'
        >>> faker.university_location()
        'Faculdade de Economia'
        >>> faker.university_location()
        'Faculdade de Direito'
        """

        return fake.random_element(UNIVERSITY_SPACES[fake.random_element(UNIVERSITY_SPACES.keys())])
