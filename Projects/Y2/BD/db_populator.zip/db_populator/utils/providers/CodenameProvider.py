from faker import Faker
fake = Faker(locale='pt_PT')

from faker.providers import BaseProvider

CODENAMES = [
    "Clube da Luta",
    "Atrasos Suspeitos",
    "O Caso do Lápis Azul",
    "Ministros, Coitados",
    "O Silêncio Dos Inocentes",
    "Vermes na Cantina",
    "Meias Rotas",
    "Operação Visconde",
    "O Código da Cerveja",
    "A Conspiração das Canetas",
    "O Barulho Dos Culpados",
    "Os Pastéis de Nata Desaparecidos",
    "O Caso do Gato de Peluche",
    "Operação Pizza Fria",
    "A Conspiração das Canetas Perdidas",
    "Os Enigmas do Campus",
    "Aventuras no Laboratório Maluco",
    "O Segredo das Salas Trancadas",
    "O Mistério dos Apagões",
    "Investigação das Aulas Desaparecidas",
    "O Enigma das Sardinhas Mágicas",
    "Os Arquivos Secretos da Biblioteca",
    "Missão Bolo de Chocolate",
    "A Saga do WiFi Misterioso",
    "O Caso das Mochilas Trocadas",
    "Os Acidentes da Máquina de Café",
    "Operação Unicornio Rosa",
    "O Caso do Papel Higiénico",
    "Os Mistérios da Hora de Almoço",
    "O Código das Sapatilhas Desaparecidas"
]

class CodenameProvider(BaseProvider):
    def codename(self) -> str:
        """Generates a random codename.
        >>> faker.codename()
        'Clube da Luta'
        >>> faker.codename()
        'Atrasos Suspeitos'
        """

        return fake.random.choice(CODENAMES)
