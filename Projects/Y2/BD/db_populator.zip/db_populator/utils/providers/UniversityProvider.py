from faker import Faker
fake = Faker(locale='pt_PT')

from faker.providers import BaseProvider

UNIVERSITIES = [
    "Universidade de Lisboa (ULisboa)",
    "Universidade do Porto (UP)",
    "Universidade de Coimbra (UC)",
    "Universidade Nova de Lisboa (UNL)",
    "Universidade de Aveiro (UA)",
    "Universidade de Évora (UE)",
    "Universidade da Beira Interior (UBI)",
    "Universidade de Trás-os-Montes e Alto Douro (UTAD)",
    "Universidade da Madeira (UMa)",
    "Universidade dos Açores (UAc)",
    "Universidade Lusófona de Humanidades e Tecnologias (ULHT)",
    "Universidade Católica Portuguesa (UCP)",
    "Universidade Lusíada (ULusíada)",
    "Universidade Autónoma de Lisboa (UAL)",
    "Universidade Europeia (UE)",
    "Universidade Fernando Pessoa (UFP)",
    "Universidade Portucalense Infante D. Henrique (UPT)",
    "Universidade Lusófona do Porto (ULP)",
    "Universidade Aberta (UAb)",
    "Instituto Politécnico de Lisboa (IPL)",
    "Instituto Politécnico do Porto (IPP)",
    "Instituto Politécnico de Coimbra (IPC)",
    "Instituto Politécnico de Leiria (IPLeiria)",
    "Instituto Politécnico de Bragança (IPB)",
    "Instituto Politécnico de Santarém (IPSantarem)",
    "Instituto Politécnico de Setúbal (IPS)",
    "Instituto Politécnico de Viseu (IPV)",
    "Instituto Politécnico de Tomar (IPT)",
    "Instituto Politécnico de Castelo Branco (IPCB)",
    "Instituto Politécnico da Guarda (IPG)",
    "Instituto Politécnico de Portalegre (IPP)",
    "Instituto Politécnico de Beja (IPBeja)",
    "Instituto Politécnico de Cávado e do Ave (IPCA)",
    "Instituto Politécnico de Viana do Castelo (IPVC)",
    "Instituto Politécnico de Braga (IPBraga)",
    "Instituto Politécnico de Santarém (IPSantarem)",
    "Instituto Politécnico de Macau (IPM)"
]

class UniversityProvider(BaseProvider):
    def university(self) -> str:
        """Generates a random university name. Has a higher chance of being "Universidade do Minho".
        >>> faker.university()
        'Universidade do Minho'
        >>> faker.university()
        'Universidade do Porto'
        >>> faker.university()
        'Universidade de Aveiro'
        """

        if fake.random.random() < 0.75:
            return "Universidade do Minho"
        else:
            return fake.random.choice(UNIVERSITIES)
