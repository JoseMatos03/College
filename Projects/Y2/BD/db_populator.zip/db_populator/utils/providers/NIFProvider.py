from faker import Faker
fake = Faker(locale='pt_PT')

from faker.providers import BaseProvider

class NIFProvider(BaseProvider):
    def nif(self) -> str:
        """ Generates a random (portuguese) NIF.
        >>> faker.nif()
        '740898379'
        >>> faker.nif()
        '287024008'
        """

        num = fake.random.randint(10000000, 99999999)
        string_num = str(num)

        num_sum = sum([int(digito) * (9 - pos) for pos, digito in enumerate(string_num)])
        remainder = num_sum % 11
        if remainder == 0: return string_num + '0'
        if remainder == 1: return string_num + '0'
        return string_num + str(11 - remainder)
