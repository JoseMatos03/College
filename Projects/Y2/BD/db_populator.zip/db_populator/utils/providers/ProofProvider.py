from faker import Faker
fake = Faker(locale='pt_PT')

from faker.providers import BaseProvider

PROOF = {
    "Observação de Manchas de Sangue": [
        "A análise das manchas de sangue confirmou a presença de múltiplas fontes de DNA no local do crime.",
        "As manchas de sangue foram identificadas como sendo de origem humana, corroborando a teoria de um ataque violento."
    ],
    "Recolha de Impressões Digitais": [
        "As impressões digitais encontradas na arma do crime correspondem às do suspeito principal, fornecendo uma ligação direta ao incidente.",
        "Após análise forense, foi confirmada a correspondência entre as impressões digitais encontradas e o perfil do suspeito no banco de dados criminais."
    ],
    "Revistar o Local de Trabalho": [
        "Documentos incriminatórios foram descobertos durante a revista ao local de trabalho, fornecendo pistas valiosas sobre possíveis motivações para o crime.",
        "Uma investigação minuciosa revelou evidências de atividades ilegais dentro da empresa, sugerindo um possível motivo para o crime."
    ],
    "Recolha de Vestígios de ADN": [
        "A análise do ADN encontrou correspondências com perfis genéticos anteriormente catalogados em bancos de dados criminais, apontando para o suspeito.",
        "O ADN encontrado nas unhas da vítima corresponde ao perfil genético do suspeito, fornecendo evidências cruciais para sua ligação ao crime."
    ],
    "Recolha de Vestígios de Pólvora": [
        "A análise dos vestígios de pólvora encontrados nas mãos do suspeito confirmou sua recente manipulação de uma arma de fogo.",
        "A presença de resíduos de pólvora em sua roupa fornece evidências adicionais da participação do suspeito no crime."
    ],
    "Monitorização de Suspeitos": [
        "Durante a monitorização do suspeito, foram observados comportamentos suspeitos consistentes com a preparação para cometer o crime.",
        "A observação detalhada do suspeito revelou sua ligação com indivíduos conhecidos por suas atividades criminosas, fortalecendo as suspeitas contra ele."
    ],
    "Recolha de Vestígios de Sangue": [
        "A análise forense das amostras de sangue encontradas no local do crime confirmou a presença do suspeito, fornecendo uma evidência crucial para sua identificação.",
        "Os vestígios de sangue encontrados no veículo do suspeito foram identificados como sendo da vítima, corroborando sua presença no local do crime."
    ],
    "Inquérito": [
        "Durante o inquérito ao cliente, foram obtidas informações cruciais de testemunhas oculares que corroboraram a versão dos eventos apresentada pelo suspeito.",
        "A análise das respostas do cliente revelou inconsistências que foram posteriormente exploradas para obter mais detalhes sobre sua participação no crime."
    ],
    "Pizza Party": [
        "A festa de pizza proporcionou um ambiente descontraído para discussões informais, levando a uma troca de ideias que resultou em novas linhas de investigação.",
        "A partilha de histórias pessoais durante a festa ajudou a construir empatia entre os membros da equipe, fortalecendo sua colaboração futura."
    ]
}



class ProofProvider(BaseProvider):
    def proof(self, procedure) -> str:
        """Generates a random proof note.
        >>> faker.proof("Inquérito")
        'Durante o inquérito ao cliente, foram obtidas informações cruciais de testemunhas oculares que corroboraram a versão dos eventos apresentada pelo suspeito.'
        >>> faker.proof("Recolha de Vestígios de Sangue")
        'Os vestígios de sangue encontrados no veículo do suspeito foram identificados como sendo da vítima, corroborando sua presença no local do crime.'
        """

        return fake.random.choice(PROOF[procedure])
